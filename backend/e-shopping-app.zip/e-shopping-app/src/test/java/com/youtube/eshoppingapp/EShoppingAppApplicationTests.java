package com.youtube.eshoppingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EShoppingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
